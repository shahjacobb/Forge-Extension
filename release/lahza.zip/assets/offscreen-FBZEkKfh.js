import{p as e}from"./chimes-1lKO3tX8.js";chrome.runtime.onMessage.addListener(i=>{i.type==="playChime"&&e(i.chime??"focus",i.volume??.7)});
